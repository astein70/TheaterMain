/**
 * Proposed solution to the third problem listed in "Design Problem - Set 2.txt".
 * @author Albert Stein 
 * @version 1.0
 */
package com.barclaycard.theatersolve;